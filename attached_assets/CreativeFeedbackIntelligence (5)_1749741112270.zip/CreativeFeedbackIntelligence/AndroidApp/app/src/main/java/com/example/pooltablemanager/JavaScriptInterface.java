package com.example.pooltablemanager;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import android.util.Log;

/**
 * JavaScript Interface class to bridge JavaScript with Android native code
 */
public class JavaScriptInterface {
    private Context context;
    private static final String TAG = "JSInterface";
    private Handler handler;

    public JavaScriptInterface(Context context) {
        this.context = context;
        this.handler = new Handler(Looper.getMainLooper());
    }

    /**
     * Show a toast message from JavaScript
     */
    @JavascriptInterface
    public void showToast(String message) {
        handler.post(() -> {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
            Log.d(TAG, "showToast: " + message);
        });
    }

    /**
     * Log messages from JavaScript to Android logcat
     */
    @JavascriptInterface
    public void logMessage(String tag, String message) {
        Log.d("WebApp-" + tag, message);
    }

    /**
     * Check if device is online
     */
    @JavascriptInterface
    public boolean isOnline() {
        // Implementation would check network connectivity
        return true;
    }

    /**
     * Save authentication token to Android preferences
     */
    @JavascriptInterface
    public void saveAuthToken(String token) {
        // Implementation would save to SharedPreferences
        Log.d(TAG, "Auth token received from web app");
    }

    /**
     * Get saved authentication token
     */
    @JavascriptInterface
    public String getAuthToken() {
        // Implementation would retrieve from SharedPreferences
        return "";
    }

    /**
     * Clear saved authentication token (logout)
     */
    @JavascriptInterface
    public void clearAuthToken() {
        // Implementation would clear from SharedPreferences
        Log.d(TAG, "Auth token cleared");
    }

    /**
     * Trigger device vibration for haptic feedback
     */
    @JavascriptInterface
    public void vibrate(int milliseconds) {
        // Implementation would use Vibrator service
        Log.d(TAG, "Vibrate request: " + milliseconds + "ms");
    }
}