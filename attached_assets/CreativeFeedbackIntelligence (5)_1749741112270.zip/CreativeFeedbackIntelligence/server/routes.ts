import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { body, validationResult } from "express-validator";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  const apiRouter = express.Router();
  
  // WordPress Proxy Routes (These will be used to proxy requests to the WordPress API)
  apiRouter.post("/wordpress/login", async (req, res) => {
    try {
      const { accountId, password } = req.body;
      
      // Forward request to WordPress (in a real implementation)
      // For now, just respond with mock data structure matching the actual API
      res.json({
        success: true,
        token: "sample-token-for-testing",
        user: {
          id: 1,
          name: "Test User",
          accountNumber: accountId,
          phoneNumber: "+1234567890",
          serialNumber: "SN12345"
        }
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ 
        success: false, 
        message: error instanceof Error ? error.message : "An unknown error occurred" 
      });
    }
  });

  apiRouter.get("/wordpress/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Forward request to WordPress (in a real implementation)
      // For now, respond with mock data structure
      res.json({
        id: userId,
        name: "Test User",
        accountNumber: "ACC12345",
        phoneNumber: "+1234567890",
        serialNumber: "SN12345",
        devices: [
          {
            id: 1,
            name: "Pool Table 1",
            serialNumber: "PT001",
            location: "Main Bar",
            balance: 150.75,
            gamesPlayed: 42,
            dailyEarnings: 25.50,
            dailyGamesPlayed: 6,
            accountNumber: "ACC12345",
            registrationDate: "2023-01-15",
            lastActivity: "2023-06-20T14:30:00",
            status: "active"
          },
          {
            id: 2,
            name: "Pool Table 2",
            serialNumber: "PT002",
            location: "Game Room",
            balance: 98.25,
            gamesPlayed: 36,
            dailyEarnings: 18.00,
            dailyGamesPlayed: 4,
            accountNumber: "ACC12345",
            registrationDate: "2023-02-10",
            lastActivity: "2023-06-19T18:45:00",
            status: "maintenance"
          }
        ]
      });
    } catch (error) {
      console.error("Get user error:", error);
      res.status(500).json({ message: error instanceof Error ? error.message : "An unknown error occurred" });
    }
  });

  apiRouter.get("/wordpress/devices", async (req, res) => {
    try {
      const accountNo = req.query.account_no;
      
      // Forward request to WordPress (in a real implementation)
      res.json([
        {
          id: 1,
          name: "Pool Table 1",
          serialNumber: "PT001",
          location: "Main Bar",
          balance: 150.75,
          gamesPlayed: 42,
          dailyEarnings: 25.50,
          dailyGamesPlayed: 6,
          accountNumber: accountNo,
          registrationDate: "2023-01-15",
          lastActivity: "2023-06-20T14:30:00",
          status: "active"
        },
        {
          id: 2,
          name: "Pool Table 2",
          serialNumber: "PT002",
          location: "Game Room",
          balance: 98.25,
          gamesPlayed: 36,
          dailyEarnings: 18.00,
          dailyGamesPlayed: 4,
          accountNumber: accountNo,
          registrationDate: "2023-02-10",
          lastActivity: "2023-06-19T18:45:00",
          status: "maintenance"
        }
      ]);
    } catch (error) {
      console.error("Get devices error:", error);
      res.status(500).json({ message: error instanceof Error ? error.message : "An unknown error occurred" });
    }
  });

  apiRouter.get("/wordpress/devices/:id/balance", async (req, res) => {
    try {
      const deviceId = parseInt(req.params.id);
      
      // Forward request to WordPress (in a real implementation)
      res.json({ balance: 150.75 });
    } catch (error) {
      console.error("Get balance error:", error);
      res.status(500).json({ message: error instanceof Error ? error.message : "An unknown error occurred" });
    }
  });

  apiRouter.post("/wordpress/withdraw", async (req, res) => {
    try {
      const { accountNo, amount } = req.body;
      
      // Forward request to WordPress (in a real implementation)
      res.json({
        success: true,
        message: "Withdrawal successful",
        amount: amount
      });
    } catch (error) {
      console.error("Withdraw error:", error);
      res.status(500).json({ 
        success: false, 
        message: error instanceof Error ? error.message : "An unknown error occurred" 
      });
    }
  });

  apiRouter.post("/wordpress/devices/:id", async (req, res) => {
    try {
      const deviceId = parseInt(req.params.id);
      const updateData = req.body;
      
      // Forward request to WordPress (in a real implementation)
      res.json({
        success: true,
        message: "Device updated successfully"
      });
    } catch (error) {
      console.error("Update device error:", error);
      res.status(500).json({ 
        success: false, 
        message: error instanceof Error ? error.message : "An unknown error occurred" 
      });
    }
  });

  // Register API routes
  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}
