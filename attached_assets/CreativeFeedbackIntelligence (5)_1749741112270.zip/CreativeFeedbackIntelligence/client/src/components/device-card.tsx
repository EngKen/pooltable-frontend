import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DeviceData } from "@shared/types";
import { formatDistanceToNow } from "date-fns";
import { Link } from "wouter";
import { Wallet, MapPin, GamepadIcon, Calendar, Activity } from "lucide-react";

interface DeviceCardProps {
  device: DeviceData;
}

export const DeviceCard = ({ device }: DeviceCardProps) => {
  // Format the last activity time
  const formattedLastActivity = device.lastActivity
    ? formatDistanceToNow(new Date(device.lastActivity), { addSuffix: true })
    : "Never";

  // Badge color based on status
  const getBadgeVariant = () => {
    switch (device.status.toLowerCase()) {
      case "active": return "bg-green-500";
      case "inactive": return "bg-red-500";
      case "maintenance": return "bg-orange-500";
      default: return "bg-gray-500";
    }
  };

  return (
    <Link href={`/device/${device.id}`}>
      <Card className="hover:shadow-md transition-shadow duration-300 cursor-pointer h-full">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start">
            <CardTitle className="text-lg font-bold truncate">{device.name}</CardTitle>
            <Badge className={`${getBadgeVariant()} text-white capitalize`}>
              {device.status}
            </Badge>
          </div>
          <div className="text-xs text-muted-foreground">
            SN: {device.serialNumber}
          </div>
        </CardHeader>
        
        <CardContent className="pt-2 pb-2 space-y-2">
          <div className="flex items-center text-sm">
            <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
            <span className="truncate">{device.location || "No location set"}</span>
          </div>
          
          <div className="flex justify-between">
            <div className="flex items-center text-sm">
              <Wallet className="h-4 w-4 mr-2 text-green-500" />
              <span className="font-medium">Ksh {device.balance.toFixed(2)}</span>
            </div>
            
            <div className="flex items-center text-sm">
              <GamepadIcon className="h-4 w-4 mr-2 text-blue-500" />
              <span>{device.gamesPlayed} games</span>
            </div>
          </div>
          
          <div className="flex justify-between text-xs text-muted-foreground">
            <div className="flex items-center">
              <Activity className="h-3 w-3 mr-1" />
              <span>Today: Ksh {device.dailyEarnings.toFixed(2)}</span>
            </div>
            
            <div className="flex items-center">
              <GamepadIcon className="h-3 w-3 mr-1" />
              <span>Today: {device.dailyGamesPlayed}</span>
            </div>
          </div>
        </CardContent>
        
        <CardFooter className="pt-2 border-t text-xs text-muted-foreground flex justify-between">
          <div className="flex items-center">
            <Calendar className="h-3 w-3 mr-1" />
            <span>Registered: {new Date(device.registrationDate).toLocaleDateString()}</span>
          </div>
          <div>Last active: {formattedLastActivity}</div>
        </CardFooter>
      </Card>
    </Link>
  );
};

export default DeviceCard;
