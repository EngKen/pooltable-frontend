import { motion } from "framer-motion";

interface LoadingSpinnerProps {
  size?: "sm" | "md" | "lg";
}

export const LoadingSpinner = ({ size = "md" }: LoadingSpinnerProps) => {
  // Size mapping
  const sizeMap = {
    sm: "w-8 h-8",
    md: "w-16 h-16",
    lg: "w-24 h-24",
  };
  
  // Animation for the spinning cue ball
  return (
    <div className="flex items-center justify-center">
      <motion.div
        className={`${sizeMap[size]} rounded-full bg-white border-4 border-gray-200 relative`}
        animate={{ rotate: 360 }}
        transition={{ 
          duration: 1.5, 
          repeat: Infinity, 
          ease: "linear" 
        }}
      >
        {/* Cue ball dots */}
        <motion.div 
          className="absolute top-1/4 left-1/4 w-2 h-2 bg-red-500 rounded-full"
          animate={{ 
            opacity: [1, 0.5, 1],
            scale: [1, 1.2, 1] 
          }}
          transition={{ 
            duration: 2, 
            repeat: Infinity,
            ease: "easeInOut" 
          }}
        />
        <motion.div 
          className="absolute bottom-1/4 right-1/4 w-2 h-2 bg-blue-500 rounded-full"
          animate={{ 
            opacity: [1, 0.5, 1],
            scale: [1, 1.2, 1] 
          }}
          transition={{ 
            duration: 2, 
            repeat: Infinity,
            ease: "easeInOut",
            delay: 0.5
          }}
        />
      </motion.div>
    </div>
  );
};

export default LoadingSpinner;
