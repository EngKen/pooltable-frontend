import { apiRequest } from "./queryClient";
import type { 
  LoginResponse, 
  UserDevicesResponse, 
  DeviceBalanceResponse, 
  WithdrawResponse,
  DeviceTransactionsResponse 
} from "@shared/types";
import type { LoginRequest, WithdrawRequest } from "@shared/schema";

// API base URL
const WORDPRESS_API_BASE = "https://kentronicssolutions.com/wp-json/pooltable/v1";

// Authentication endpoints
export async function loginUser(credentials: LoginRequest): Promise<LoginResponse> {
  const response = await apiRequest("POST", `${WORDPRESS_API_BASE}/login`, credentials);
  return response.json();
}

// Device endpoints
export async function getUserData(userId: string, token: string): Promise<UserDevicesResponse> {
  // Since the /users/:id endpoint doesn't seem to work with the string ID format,
  // we'll use the getUserDevices function that fetches from /devices endpoint instead
  // This function is kept for compatibility with existing code
  const user = JSON.parse(localStorage.getItem("user") || "{}");
  return getUserDevices(user.accountNumber, token);
}

export async function getUserDevices(accountNo: string, token: string): Promise<UserDevicesResponse> {
  const response = await fetch(`${WORDPRESS_API_BASE}/devices?account_no=${accountNo}`, {
    headers: {
      "Authorization": `Bearer ${token}`
    },
    credentials: "include"
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`${response.status}: ${text || response.statusText}`);
  }

  const devices = await response.json();

  // Create a user devices response with the device data
  const user = JSON.parse(localStorage.getItem("user") || "{}");
  return {
    ...user,
    devices: devices
  };
}

export async function getDeviceBalance(deviceId: string, token: string): Promise<DeviceBalanceResponse> {
  const response = await fetch(`${WORDPRESS_API_BASE}/devices/${deviceId}/balance`, {
    headers: {
      "Authorization": `Bearer ${token}`
    },
    credentials: "include"
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`${response.status}: ${text || response.statusText}`);
  }

  return response.json();
}

export async function withdrawFunds(data: WithdrawRequest, token: string): Promise<WithdrawResponse> {
  const response = await fetch(`${WORDPRESS_API_BASE}/withdraw`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`
    },
    body: JSON.stringify(data),
    credentials: "include"
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`${response.status}: ${text || response.statusText}`);
  }

  return response.json();
}

export async function updateDeviceInfo(
  deviceId: string, 
  data: Partial<{ name: string; location: string; status: string; phoneNumber: string }>,
  token: string
): Promise<{ success: boolean }> {
  const response = await fetch(`${WORDPRESS_API_BASE}/devices/${deviceId}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`
    },
    body: JSON.stringify(data),
    credentials: "include"
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`${response.status}: ${text || response.statusText}`);
  }

  return { success: true };
}

export async function getDeviceTransactions(deviceId: string, token: string): Promise<DeviceTransactionsResponse> {
  return apiRequest(`/api/wordpress/devices/${deviceId}/transactions`, {
    method: "GET",
    headers: { Authorization: `Bearer ${token}` },
  });
}

export type {
  LoginResponse,
  UserDevicesResponse,
  DeviceBalanceResponse,
  WithdrawResponse,
  DeviceTransactionsResponse,
};