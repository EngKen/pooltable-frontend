import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useAuth } from "@/lib/use-auth";
import { getUserData } from "@/lib/api";
import { DeviceData } from "@shared/types";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import LoadingSpinner from "@/components/loading-spinner";
import DeviceCard from "@/components/device-card";
import { LogOut, RefreshCw, Wallet, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Dashboard() {
  const { user, token, logout, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);
  
  // Fetch user data with devices
  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ['/api/user', user?.id],
    queryFn: () => getUserData(user?.id || "", token || ""),
    enabled: !!user?.id && !!token,
  });

  // Calculate total balance
  const totalBalance = data?.devices?.reduce(
    (sum, device) => sum + device.balance, 
    0
  ) || 0;

  // Calculate active devices
  const activeDevices = data?.devices?.filter(
    device => device.status.toLowerCase() === "active"
  ).length || 0;

  // Prepare device groups
  const allDevices = data?.devices || [];
  const activeDevicesList = data?.devices?.filter(
    device => device.status.toLowerCase() === "active"
  ) || [];
  const inactiveDevicesList = data?.devices?.filter(
    device => device.status.toLowerCase() !== "active"
  ) || [];

  const handleWithdrawClick = () => {
    setLocation("/withdraw");
  };

  if (!isAuthenticated) {
    return null; // Will redirect via useEffect
  }

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <LoadingSpinner size="lg" />
        <p className="mt-4 text-lg">Loading your dashboard...</p>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <AlertCircle className="h-16 w-16 text-red-500 mb-4" />
        <h2 className="text-lg font-bold mb-2">Error loading data</h2>
        <p className="text-muted-foreground mb-4">Could not load your device information</p>
        <div className="flex gap-4">
          <Button onClick={() => refetch()}>Try Again</Button>
          <Button variant="outline" onClick={logout}>Logout</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 max-w-5xl">
      {/* Header with user info */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">{data?.name || user?.name}</h1>
          <p className="text-muted-foreground">
            Account: {data?.accountNumber || user?.accountNumber}
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="icon"
            onClick={() => refetch()}
            title="Refresh data"
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="icon"
            onClick={logout}
            title="Logout"
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <Wallet className="h-6 w-6 mr-2 text-green-500" />
                <span className="text-2xl font-bold">Ksh {totalBalance.toFixed(2)}</span>
              </div>
              <Button 
                className="w-full mt-2" 
                variant="default"
                onClick={handleWithdrawClick}
                disabled={totalBalance <= 0}
              >
                Withdraw
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Devices</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{allDevices.length}</div>
              <p className="text-muted-foreground">{activeDevices} active</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Last Update</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-medium">
                {allDevices.length > 0 
                  ? new Date().toLocaleString()
                  : "No devices found"
                }
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Devices tabs */}
      <Tabs defaultValue="all" className="mb-6">
        <TabsList className="w-full grid grid-cols-3">
          <TabsTrigger value="all">All Devices ({allDevices.length})</TabsTrigger>
          <TabsTrigger value="active">Active ({activeDevicesList.length})</TabsTrigger>
          <TabsTrigger value="inactive">Inactive ({inactiveDevicesList.length})</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-4">
          <DeviceGrid devices={allDevices} />
        </TabsContent>
        
        <TabsContent value="active" className="mt-4">
          <DeviceGrid devices={activeDevicesList} />
        </TabsContent>
        
        <TabsContent value="inactive" className="mt-4">
          <DeviceGrid devices={inactiveDevicesList} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Device grid component
interface DeviceGridProps {
  devices: DeviceData[];
}

function DeviceGrid({ devices }: DeviceGridProps) {
  if (devices.length === 0) {
    return (
      <div className="text-center p-8 border rounded-lg bg-gray-50">
        <p className="text-muted-foreground">No devices found in this category</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      <AnimatePresence>
        {devices.map((device, index) => (
          <motion.div
            key={device.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.05 }}
          >
            <DeviceCard device={device} />
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
