import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/lib/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getUserData, withdrawFunds } from "@/lib/api";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import LoadingSpinner from "@/components/loading-spinner";
import { ArrowLeft, CircleDollarSign, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";

// Withdraw form schema
const withdrawFormSchema = z.object({
  amount: z.string()
    .transform((val) => parseFloat(val))
    .refine((val) => !isNaN(val), {
      message: "Amount must be a valid number",
    })
    .refine((val) => val > 0, {
      message: "Amount must be greater than 0",
    }),
});

type WithdrawFormValues = z.infer<typeof withdrawFormSchema>;

export default function Withdraw() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { user, token, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);

  // Fetch user data for balance
  const { data: userData, isLoading, isError } = useQuery({
    queryKey: ['/api/user'],
    queryFn: () => getUserData(0, token || ""),
    enabled: !!token && isAuthenticated,
  });

  // Calculate total balance
  const totalBalance = userData?.devices?.reduce(
    (sum, device) => sum + device.balance, 
    0
  ) || 0;

  // Form definition
  const form = useForm<WithdrawFormValues>({
    resolver: zodResolver(withdrawFormSchema),
    defaultValues: {
      amount: "",
    },
  });

  // Withdraw mutation
  const withdrawMutation = useMutation({
    mutationFn: (amount: number) => {
      return withdrawFunds(
        { 
          accountNo: user?.accountNumber || userData?.accountNumber || "",
          amount 
        },
        token || ""
      );
    },
    onSuccess: () => {
      toast({
        title: "Withdrawal successful",
        description: "Your funds are being processed",
      });

      // Invalidate relevant queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });

      // Redirect back to dashboard
      setTimeout(() => {
        setLocation("/dashboard");
      }, 1500);
    },
    onError: (error) => {
      console.error("Withdrawal error:", error);
      toast({
        title: "Withdrawal failed",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsSubmitting(false);
    }
  });

  // Form submission handler
  const onSubmit = async (values: WithdrawFormValues) => {
    if (values.amount > totalBalance) {
      toast({
        title: "Insufficient funds",
        description: "Withdrawal amount exceeds your total balance",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    withdrawMutation.mutate(values.amount);
  };

  const handleBack = () => {
    setLocation("/dashboard");
  };

  if (!isAuthenticated) {
    return null; // Will redirect via useEffect
  }

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <LoadingSpinner size="lg" />
        <p className="mt-4 text-lg">Loading your balance...</p>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <AlertCircle className="h-16 w-16 text-red-500 mb-4" />
        <h2 className="text-lg font-bold mb-2">Error loading data</h2>
        <p className="text-muted-foreground mb-4">Could not load your account information</p>
        <Button onClick={handleBack}>Back to Dashboard</Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 max-w-md min-h-screen flex flex-col justify-center">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="mb-4"
      >
        <Button variant="ghost" size="icon" onClick={handleBack}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3, delay: 0.1 }}
      >
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CircleDollarSign className="h-6 w-6 text-green-500" />
              Withdraw Funds
            </CardTitle>
            <CardDescription>
              Available balance: Ksh {totalBalance.toFixed(2)}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Withdrawal Amount</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                            Ksh
                          </span>
                          <Input 
                            placeholder="0.00" 
                            {...field} 
                            disabled={isSubmitting || totalBalance <= 0}
                            className="pl-8"
                            type="number"
                            step="0.01"
                            min="0.01"
                            max={totalBalance}
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={isSubmitting || totalBalance <= 0}
                >
                  {isSubmitting ? (
                    <div className="flex items-center">
                      <LoadingSpinner size="sm" />
                      <span className="ml-2">Processing...</span>
                    </div>
                  ) : (
                    "Withdraw Funds"
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex justify-center text-center text-sm text-muted-foreground">
            <p>Contact us at support@kentronicssolutions.com</p>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
}