import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation, useParams } from "wouter";
import { useAuth } from "@/lib/use-auth";
import { getUserData, getDeviceBalance, getDeviceTransactions } from "@/lib/api"; // Added getDeviceTransactions
import { DeviceData, Transaction } from "@shared/types"; // Added Transaction type

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import LoadingSpinner from "@/components/loading-spinner";
import {
  ArrowLeft,
  Wallet,
  MapPin,
  Calendar,
  Phone,
  GamepadIcon,
  Activity,
  RefreshCw,
  AlertCircle,
  Search,
} from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input"; // Added Input component
import { Table, TableBody, TableCell, TableHeader, TableHead, TableRow } from "@/components/ui/table"; // Added Table components


export default function DeviceDetail() {
  const { id } = useParams();
  const deviceId = id;
  const { token, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([]); // Added state for filtered transactions
  const [allTransactions, setAllTransactions] = useState<Transaction[]>([]); // Added state for all transactions


  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);

  const { data: userData, isLoading: userLoading, isError: userError } = useQuery({
    queryKey: ['/api/user'],
    queryFn: () => getUserData("", token || ""),
    enabled: !!token && isAuthenticated,
  });

  const {
    data: balanceData,
    isLoading: balanceLoading,
    refetch: refetchBalance
  } = useQuery({
    queryKey: ['/api/device/balance', deviceId],
    queryFn: () => getDeviceBalance(deviceId || "", token || ""),
    enabled: !!token && isAuthenticated && !!deviceId,
  });

  const { data: transactionsData, isLoading: transactionsLoading } = useQuery({ // Fetch transactions
    queryKey: ['/api/device/transactions', deviceId],
    queryFn: () => getDeviceTransactions(deviceId || "", token || ""),
    enabled: !!token && isAuthenticated && !!deviceId,
  });


  useEffect(() => {
    if (transactionsData) {
      setAllTransactions(transactionsData);
      setFilteredTransactions(transactionsData);
    }
  }, [transactionsData]);


  const device = userData?.devices?.find((d: DeviceData) => d.id === deviceId);

  const isLoading = userLoading || balanceLoading || transactionsLoading; // Include transactions loading
  const isError = userError;

  const handleBack = () => {
    setLocation("/dashboard");
  };

  const handleWithdraw = () => {
    setLocation("/withdraw");
  };

  if (!isAuthenticated) {
    return null;
  }

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <LoadingSpinner size="lg" />
        <p className="mt-4 text-lg">Loading device details...</p>
      </div>
    );
  }

  if (isError || !device) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <AlertCircle className="h-16 w-16 text-red-500 mb-4" />
        <h2 className="text-lg font-bold mb-2">Device not found</h2>
        <p className="text-muted-foreground mb-4">Could not load the device information</p>
        <Button onClick={handleBack}>Back to Dashboard</Button>
      </div>
    );
  }

  const getBadgeVariant = () => {
    switch (device.status.toLowerCase()) {
      case "active": return "bg-green-500";
      case "inactive": return "bg-red-500";
      case "maintenance": return "bg-orange-500";
      default: return "bg-gray-500";
    }
  };

  return (
    <div className="container mx-auto p-4 max-w-5xl">
      <div className="flex items-center mb-6">
        <Button variant="ghost" size="icon" onClick={handleBack} className="mr-2">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-bold">Device Details</h1>
        <Button
          variant="outline"
          size="icon"
          className="ml-auto"
          onClick={() => refetchBalance()}
        >
          <RefreshCw className="h-4 w-4" />
        </Button>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <Card className="mb-6">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <CardTitle>{device.name}</CardTitle>
              <Badge className={`${getBadgeVariant()} text-white capitalize`}>
                {device.status}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground">
              Serial: {device.serialNumber}
            </p>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center">
                <Wallet className="h-5 w-5 mr-2 text-green-500" />
                <div>
                  <p className="text-sm text-muted-foreground">Current Balance</p>
                  <p className="text-2xl font-bold">
                    Ksh {typeof balanceData?.balance === 'number'
                      ? balanceData.balance.toFixed(2)
                      : device.balance.toFixed(2)}
                  </p>
                </div>
                <Button
                  className="ml-auto"
                  disabled={device.balance <= 0}
                  onClick={handleWithdraw}
                >
                  Withdraw
                </Button>
              </div>

              <Separator />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>{device.location || "No location set"}</span>
                  </div>

                  <div className="flex items-center">
                    <Phone className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>{userData?.phoneNumber || "No phone number"}</span>
                  </div>

                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>Registered: {new Date(device.registrationDate).toLocaleDateString()}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center">
                    <GamepadIcon className="h-4 w-4 mr-2 text-blue-500" />
                    <span>Total Games: {device.gamesPlayed}</span>
                  </div>

                  <div className="flex items-center">
                    <Activity className="h-4 w-4 mr-2 text-purple-500" />
                    <span>Today's Earnings: Ksh {device.dailyEarnings.toFixed(2)}</span>
                  </div>

                  <div className="flex items-center">
                    <GamepadIcon className="h-4 w-4 mr-2 text-purple-500" />
                    <span>Today's Games: {device.dailyGamesPlayed}</span>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="text-sm text-muted-foreground">
                <p>Last Updated: {device.lastActivity
                  ? new Date(device.lastActivity).toLocaleString()
                  : "Unknown"}</p>
                <p>Account: {device.accountNumber}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Activity section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.3 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Activity Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardHeader className="py-2">
                    <p className="text-sm text-muted-foreground">Total Earnings</p>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xl font-bold">Ksh {device.balance.toFixed(2)}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="py-2">
                    <p className="text-sm text-muted-foreground">Total Games</p>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xl font-bold">{device.gamesPlayed}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="py-2">
                    <p className="text-sm text-muted-foreground">Today's Earnings</p>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xl font-bold">Ksh {device.dailyEarnings.toFixed(2)}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="py-2">
                    <p className="text-sm text-muted-foreground">Today's Games</p>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xl font-bold">{device.dailyGamesPlayed}</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Transaction History */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.3 }}
      >
        <Card className="mt-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Transaction History</CardTitle>
              <div className="relative w-64">
                <Input
                  type="search"
                  placeholder="Search by phone or transaction ID..."
                  className="pr-8"
                  onChange={(e) => {
                    const searchTerm = e.target.value.toLowerCase();
                    const filtered = allTransactions.filter(t =>
                      t.phoneNumber.toLowerCase().includes(searchTerm) ||
                      t.transactionId.toLowerCase().includes(searchTerm)
                    );
                    setFilteredTransactions(filtered);
                  }}
                />
                <Search className="absolute right-2 top-2.5 h-4 w-4 text-muted-foreground" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(groupTransactionsByDate(filteredTransactions || [])).map(([date, transactions]) => (
                <div key={date} className="space-y-2">
                  <h3 className="font-medium text-muted-foreground">{date}</h3>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Time</TableHead>
                          <TableHead>Name</TableHead>
                          <TableHead>Phone</TableHead>
                          <TableHead className="text-right">Amount</TableHead>
                          <TableHead className="text-right">Balance</TableHead>
                          <TableHead>Transaction ID</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {transactions.map((transaction) => (
                          <TableRow key={transaction.id}>
                            <TableCell>{new Date(transaction.timestamp).toLocaleTimeString()}</TableCell>
                            <TableCell>{transaction.customerName}</TableCell>
                            <TableCell>{transaction.phoneNumber}</TableCell>
                            <TableCell className="text-right">Ksh {transaction.amount.toFixed(2)}</TableCell>
                            <TableCell className="text-right">Ksh {transaction.runningBalance.toFixed(2)}</TableCell>
                            <TableCell className="font-mono">{transaction.transactionId}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}

function groupTransactionsByDate(transactions: Transaction[]) {
  return transactions.reduce((groups, transaction) => {
    const date = new Date(transaction.timestamp).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(transaction);
    return groups;
  }, {} as Record<string, Transaction[]>);
}