import { pgTable, text, serial, numeric, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema (for local authentication)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Pool table device registration
export const deviceRegistration = pgTable("wp_device_registration", {
  device_id: serial("device_id").primaryKey(),
  device_serial_number: text("device_serial_number").notNull(),
  owner_name: text("owner_name").notNull(),
  owner_number: text("owner_number").notNull(),
  account_no: text("account_no").notNull(),
  device_sim_number: text("device_sim_number"),
  location: text("location"),
  status: text("status").default("active"),
  date_of_registration: timestamp("date_of_registration").defaultNow(),
  password: text("password").notNull(),
});

export const insertDeviceRegistrationSchema = createInsertSchema(deviceRegistration).omit({
  device_id: true,
  date_of_registration: true,
});

export type InsertDeviceRegistration = z.infer<typeof insertDeviceRegistrationSchema>;
export type DeviceRegistration = typeof deviceRegistration.$inferSelect;

// Pool table device balances
export const deviceBalances = pgTable("wp_device_balances", {
  id: serial("id").primaryKey(),
  device_id: integer("device_id").notNull(),
  balance: numeric("balance", { precision: 10, scale: 2 }).default("0"),
  games_paid: integer("games_paid").default(0),
  daily_earnings: numeric("daily_earnings", { precision: 10, scale: 2 }).default("0"),
  daily_gamespaid: integer("daily_gamespaid").default(0),
  last_updated: timestamp("last_updated").defaultNow(),
});

export const insertDeviceBalancesSchema = createInsertSchema(deviceBalances).omit({
  id: true,
  last_updated: true,
});

export type InsertDeviceBalances = z.infer<typeof insertDeviceBalancesSchema>;
export type DeviceBalances = typeof deviceBalances.$inferSelect;

// Transaction records
export const transactions = pgTable("wp_device_transactions", {
  id: serial("id").primaryKey(),
  device_id: integer("device_id").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
  customer_name: text("customer_name").notNull(),
  phone_number: text("phone_number").notNull(),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  running_balance: numeric("running_balance", { precision: 10, scale: 2 }).notNull(),
  transaction_id: text("transaction_id").notNull(),
});

// Login schema
export const loginSchema = z.object({
  accountId: z.string().min(1, "Account ID is required"),
  password: z.string().min(1, "Password is required"),
});

// Withdrawal schema
export const withdrawSchema = z.object({
  accountNo: z.string().min(1, "Account number is required"),
  amount: z.number().positive("Amount must be positive"),
});

export type LoginRequest = z.infer<typeof loginSchema>;
export type WithdrawRequest = z.infer<typeof withdrawSchema>;
