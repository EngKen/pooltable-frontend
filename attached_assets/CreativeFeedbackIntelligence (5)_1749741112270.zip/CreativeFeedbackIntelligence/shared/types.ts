// API Response Types

export interface LoginResponse {
  success: boolean;
  token?: string;
  user?: UserData;
  message?: string;
}

export interface UserData {
  id: string;
  name: string;
  accountNumber: string;
  phoneNumber: string;
  serialNumber: string;
}

export interface DeviceData {
  id: string;
  name: string;
  serialNumber: string;
  location: string;
  balance: number;
  gamesPlayed: number;
  dailyEarnings: number;
  dailyGamesPlayed: number;
  accountNumber: string;
  registrationDate: string;
  lastActivity: string | null;
  status: string;
}

export interface UserDevicesResponse {
  id: string;
  name: string;
  accountNumber: string;

export interface Transaction {
  id: string;
  deviceId: string;
  timestamp: string;
  customerName: string;
  phoneNumber: string;
  amount: number;
  runningBalance: number;
  transactionId: string;
}

export interface DeviceTransactionsResponse {
  transactions: Transaction[];
}

  phoneNumber: string;
  serialNumber: string;
  devices: DeviceData[];
}

export interface DeviceBalanceResponse {
  balance: number;
}

export interface WithdrawResponse {
  success: boolean;
  message: string;
  amount?: number;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: UserData | null;
  token: string | null;
  login: (accountId: string, password: string) => Promise<boolean>;
  logout: () => void;
}
